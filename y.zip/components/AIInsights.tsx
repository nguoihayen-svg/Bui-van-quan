
import React, { useState } from 'react';
import { BrainCircuit, Sparkles, RefreshCw, AlertCircle } from 'lucide-react';
import { Product, Transaction } from '../types';
import { getAIInsights } from '../services/geminiService';

interface AIInsightsProps {
  products: Product[];
  transactions: Transaction[];
}

const AIInsights: React.FC<AIInsightsProps> = ({ products, transactions }) => {
  const [loading, setLoading] = useState(false);
  const [insights, setInsights] = useState<string | null>(null);

  const generateInsights = async () => {
    setLoading(true);
    const result = await getAIInsights(products, transactions);
    setInsights(result);
    setLoading(false);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-4xl mx-auto">
      <div className="text-center space-y-4">
        <div className="w-16 h-16 bg-indigo-100 text-indigo-600 rounded-2xl flex items-center justify-center mx-auto shadow-sm">
          <BrainCircuit size={32} />
        </div>
        <h2 className="text-3xl font-bold tracking-tight">AI Business Insights</h2>
        <p className="text-slate-500">Sử dụng trí tuệ nhân tạo (Gemini) để phân tích xu hướng kinh doanh của cửa hàng bạn.</p>
        
        <button 
          onClick={generateInsights}
          disabled={loading || transactions.length === 0}
          className="inline-flex items-center gap-2 px-8 py-3 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? <RefreshCw className="animate-spin" size={20} /> : <Sparkles size={20} />}
          {insights ? 'Làm mới báo cáo' : 'Bắt đầu phân tích'}
        </button>
      </div>

      {transactions.length === 0 && (
        <div className="p-4 bg-amber-50 border border-amber-100 rounded-xl flex gap-3 text-amber-700 text-sm">
          <AlertCircle className="shrink-0" />
          <p>Bạn cần có ít nhất vài giao dịch để AI có thể phân tích dữ liệu hiệu quả.</p>
        </div>
      )}

      {insights && (
        <div className="bg-white border border-slate-200 rounded-3xl shadow-xl overflow-hidden animate-in slide-in-from-bottom-8 duration-500">
          <div className="bg-slate-50 px-8 py-4 border-b border-slate-100 flex items-center gap-2">
            <Sparkles className="text-amber-500" size={18} />
            <h4 className="font-bold text-slate-700">Báo cáo chiến lược</h4>
          </div>
          <div className="p-8 prose prose-slate max-w-none prose-h1:text-2xl prose-h2:text-xl prose-p:leading-relaxed prose-li:my-1">
             <div className="whitespace-pre-line text-slate-700">
               {insights.replace(/```markdown/g, '').replace(/```/g, '')}
             </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          { title: "Bán chạy", desc: "Mặt hàng hot nhất tuần qua" },
          { title: "Gợi ý KM", desc: "Giảm giá để xả hàng tồn lâu" },
          { title: "Dự báo", desc: "Xu hướng nhập hàng tháng tới" }
        ].map((item, i) => (
          <div key={i} className="p-6 bg-slate-50 border border-slate-200 rounded-2xl">
            <h5 className="font-bold text-slate-900 mb-1">{item.title}</h5>
            <p className="text-sm text-slate-500">{item.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AIInsights;
