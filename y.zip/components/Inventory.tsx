
import React, { useState, useMemo, useEffect } from 'react';
import { Plus, Edit2, Trash2, Filter, Package, Image as ImageIcon, X, MapPin, AlertCircle, RefreshCw, DownloadCloud, Loader2 } from 'lucide-react';
import { Product } from '../types';

interface InventoryProps {
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  search: string;
  categories: string[];
  adminPassword?: string;
  onPull?: () => void;
  isPulling?: boolean;
  showCostPrice?: boolean;
}

const PasswordModal: React.FC<{
  onClose: () => void;
  onSuccess: () => void;
  correctPassword?: string;
  title?: string;
  description?: string;
}> = ({ onClose, onSuccess, correctPassword, title = "Xác nhận mật khẩu", description = "Vui lòng nhập mật khẩu để thực hiện thay đổi." }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);
  const [showHelp, setShowHelp] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!correctPassword || password === correctPassword) {
      onSuccess();
    } else {
      setError(true);
      setTimeout(() => setError(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl w-full max-w-sm shadow-2xl animate-in zoom-in-95 duration-200 overflow-hidden">
        <div className="p-8 text-center space-y-6">
          <div className="w-20 h-20 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
            <AlertCircle size={40} />
          </div>
          
          {!showHelp ? (
            <>
              <div>
                <h3 className="text-2xl font-bold text-slate-900">{title}</h3>
                <p className="text-sm text-slate-500 mt-2">{description}</p>
              </div>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="relative">
                  <input 
                    autoFocus
                    type="password" 
                    className={`w-full px-4 py-4 rounded-2xl border transition-all outline-none text-center text-2xl tracking-[0.5em] font-mono ${
                      error ? 'border-rose-500 ring-rose-100 ring-4' : 'border-slate-200 focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500'
                    }`}
                    placeholder="••••"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                  />
                  {error && <p className="text-xs font-bold text-rose-500 mt-2 animate-shake">Mật khẩu không chính xác!</p>}
                </div>
                
                <div className="flex flex-col gap-3">
                  <button type="submit" className="w-full py-4 rounded-2xl bg-indigo-600 text-white font-bold shadow-xl shadow-indigo-200 hover:bg-indigo-700 active:scale-[0.98] transition-all">
                    Xác nhận
                  </button>
                  <button type="button" onClick={onClose} className="w-full py-4 rounded-2xl border border-slate-200 font-bold text-slate-500 hover:bg-slate-50 transition-all">
                    Hủy bỏ
                  </button>
                  <button 
                    type="button" 
                    onClick={() => setShowHelp(true)}
                    className="text-xs font-bold text-indigo-500 hover:underline mt-2"
                  >
                    Quên mật khẩu?
                  </button>
                </div>
              </form>
            </>
          ) : (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
              <div className="text-left space-y-4">
                <h3 className="text-xl font-bold text-slate-900">Khôi phục mật khẩu</h3>
                <div className="space-y-3 text-sm text-slate-600 leading-relaxed">
                  <p>1. Nếu bạn đã đồng bộ với Cloud, hãy mở file <b>Google Sheets</b> của bạn.</p>
                  <p>2. Tìm trang tính (Sheet) có tên là <b>"Passwords"</b>.</p>
                  <p>3. Bạn sẽ thấy mật khẩu hiện tại ở đó. Bạn có thể xem hoặc đổi trực tiếp trên Sheet.</p>
                  <p>4. Nếu chưa từng đổi, mật khẩu mặc định là: <code className="bg-slate-100 px-2 py-0.5 rounded font-bold text-indigo-600">admin</code></p>
                </div>
              </div>
              <button 
                type="button" 
                onClick={() => setShowHelp(false)}
                className="w-full py-4 rounded-2xl bg-slate-900 text-white font-bold hover:bg-slate-800 transition-all"
              >
                Quay lại nhập mật khẩu
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export { PasswordModal };

const ProductModal: React.FC<{
  editingProduct: Product | null;
  categories: string[];
  existingProducts: Product[];
  onClose: () => void;
  onSubmit: (data: Partial<Product>) => void;
}> = ({ editingProduct, categories, existingProducts, onClose, onSubmit }) => {
  const [formData, setFormData] = useState<Partial<Product>>(
    editingProduct || { 
      name: '', 
      category: categories[0] || 'Khác', 
      costPrice: 0, 
      salePrice: 0, 
      stock: 0,
      imageUrl: `https://picsum.photos/seed/${Math.random()}/400/400`,
      sku: '',
      location: ''
    }
  );

  // LOGIC KIỂM TRA TRÙNG LẶP ĐÃ ĐƯỢC SỬA LỖI
  const duplicates = useMemo(() => {
    // Chỉ kiểm tra trùng với các sản phẩm KHÁC sản phẩm đang sửa
    const otherProducts = existingProducts.filter(p => 
      editingProduct ? String(p.id) !== String(editingProduct.id) : true
    );
    
    const nameVal = (formData.name || '').toLowerCase().trim();
    const skuVal = (formData.sku || '').toLowerCase().trim();
    const locVal = (formData.location || '').toLowerCase().trim();

    return {
      name: nameVal ? otherProducts.filter(p => p.name.toLowerCase().trim() === nameVal) : [],
      sku: skuVal ? otherProducts.find(p => p.sku.toLowerCase().trim() === skuVal) : null,
      location: (locVal && locVal !== '') ? otherProducts.find(p => p.location?.toLowerCase().trim() === locVal) : null
    };
  }, [formData.name, formData.sku, formData.location, existingProducts, editingProduct]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (duplicates.sku || duplicates.location) {
      alert("Mã SKU hoặc Vị trí đang bị trùng lặp với sản phẩm khác. Vui lòng kiểm tra lại!");
      return;
    }
    onSubmit(formData);
  };

  // Nút Lưu chỉ bị vô hiệu hóa nếu trùng SKU hoặc Vị trí (Tên trùng chỉ hiện cảnh báo nhắc nhở)
  const isInvalid = !!duplicates.sku || !!duplicates.location;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl animate-in zoom-in-95 duration-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center">
          <h3 className="text-xl font-bold">{editingProduct ? 'Chỉnh sửa sản phẩm' : 'Thêm sản phẩm mới'}</h3>
          <button type="button" onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors">
            <X size={20} />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[85vh] overflow-y-auto custom-scrollbar">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="block text-sm font-bold text-slate-700 mb-1">Tên sản phẩm</label>
              <input 
                required 
                type="text" 
                className={`w-full px-4 py-2 rounded-xl border transition-all outline-none focus:ring-2 ${
                  duplicates.name.length > 0 ? 'border-amber-400 ring-amber-100' : 'border-slate-200 focus:ring-indigo-500'
                }`}
                value={formData.name} 
                onChange={e => setFormData({...formData, name: e.target.value})} 
              />
              {duplicates.name.length > 0 && (
                <div className="mt-1.5 p-2 bg-amber-50 rounded-lg border border-amber-100">
                  <p className="text-[10px] font-bold text-amber-700 flex items-center gap-1 uppercase tracking-tight">
                    <AlertCircle size={10} /> Lưu ý: Tên này trùng với {duplicates.name.length} SP khác
                  </p>
                </div>
              )}
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">Mã SKU</label>
              <input 
                required 
                type="text" 
                className={`w-full px-4 py-2 rounded-xl border transition-all outline-none focus:ring-2 ${
                  duplicates.sku ? 'border-rose-500 ring-rose-200' : 'border-slate-200 focus:ring-indigo-500'
                }`}
                value={formData.sku} 
                onChange={e => setFormData({...formData, sku: e.target.value})} 
              />
              {duplicates.sku && (
                <p className="text-[10px] text-rose-600 font-bold mt-1 flex items-center gap-1">
                  <AlertCircle size={10} /> SKU đã dùng cho: {duplicates.sku.name}
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">Vị trí trong kho</label>
              <input 
                type="text" 
                placeholder="Ví dụ: Kệ A1" 
                className={`w-full px-4 py-2 rounded-xl border transition-all outline-none focus:ring-2 ${
                  duplicates.location ? 'border-rose-500 ring-rose-200' : 'border-slate-200 focus:ring-indigo-500'
                }`}
                value={formData.location} 
                onChange={e => setFormData({...formData, location: e.target.value})} 
              />
              {duplicates.location && (
                <p className="text-[10px] text-rose-600 font-bold mt-1 flex items-center gap-1">
                  <AlertCircle size={10} /> Vị trí này có: {duplicates.location.name}
                </p>
              )}
            </div>

            <div className="col-span-2 md:col-span-1">
              <label className="block text-sm font-bold text-slate-700 mb-1">Danh mục</label>
              <select className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 appearance-none bg-white cursor-pointer" 
                value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})}>
                {categories.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>

            <div className="col-span-2 md:col-span-1">
              <label className="block text-sm font-bold text-slate-700 mb-1">Số lượng tồn</label>
              <input required type="number" className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500" 
                value={formData.stock} onChange={e => setFormData({...formData, stock: Number(e.target.value)})} />
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">Giá nhập (VNĐ)</label>
              <input required type="number" className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 font-mono text-emerald-600 font-bold" 
                value={formData.costPrice} onChange={e => setFormData({...formData, costPrice: Number(e.target.value)})} />
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">Giá bán (VNĐ)</label>
              <input required type="number" className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 font-mono text-indigo-600 font-bold" 
                value={formData.salePrice} onChange={e => setFormData({...formData, salePrice: Number(e.target.value)})} />
            </div>

            <div className="col-span-2">
              <label className="block text-sm font-bold text-slate-700 mb-1">Hình ảnh (URL)</label>
              <input type="text" className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 text-xs" 
                value={formData.imageUrl} onChange={e => setFormData({...formData, imageUrl: e.target.value})} />
            </div>
          </div>
          <div className="flex gap-3 pt-4">
            <button type="button" onClick={onClose} className="flex-1 py-3 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 transition-all active:scale-95">
              Hủy
            </button>
            <button 
              type="submit" 
              className={`flex-1 py-3 rounded-xl text-white font-bold shadow-lg transition-all active:scale-95 ${
                isInvalid ? 'bg-slate-400 cursor-not-allowed shadow-none' : 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-100'
              }`}
            >
              Lưu sản phẩm
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

const Inventory: React.FC<InventoryProps> = ({ products, setProducts, search, categories, adminPassword, onPull, isPulling, showCostPrice }) => {
  const [showModal, setShowModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [filterCategory, setFilterCategory] = useState<string>('All');
  
  // Password protection state
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [pendingAction, setPendingAction] = useState<{ type: 'submit' | 'delete', data?: any } | null>(null);

  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase()) || 
                           p.sku.toLowerCase().includes(search.toLowerCase()) ||
                           (p.location && p.location.toLowerCase().includes(search.toLowerCase()));
      const matchesCategory = filterCategory === 'All' || p.category === filterCategory;
      return matchesSearch && matchesCategory;
    });
  }, [products, search, filterCategory]);

  const handleDelete = (id: string) => {
    if (confirm('Bạn chắc chắn muốn xóa sản phẩm này?')) {
      if (adminPassword) {
        setPendingAction({ type: 'delete', data: id });
        setShowPasswordModal(true);
      } else {
        setProducts(products.filter(p => p.id !== id));
      }
    }
  };

  const handleModalSubmit = (formData: Partial<Product>) => {
    if (adminPassword) {
      setPendingAction({ type: 'submit', data: formData });
      setShowPasswordModal(true);
    } else {
      executeSubmit(formData);
    }
  };

  const executeSubmit = (formData: Partial<Product>) => {
    if (editingProduct) {
      setProducts(prev => prev.map(p => p.id === editingProduct.id ? { ...p, ...formData } as Product : p));
    } else {
      const newProd = { ...formData, id: Date.now().toString() } as Product;
      setProducts(prev => [...prev, newProd]);
    }
    setEditingProduct(null);
    setShowModal(false);
  };

  const handlePasswordSuccess = () => {
    if (pendingAction) {
      if (pendingAction.type === 'delete') {
        setProducts(products.filter(p => p.id !== pendingAction.data));
      } else if (pendingAction.type === 'submit') {
        executeSubmit(pendingAction.data);
      }
    }
    setShowPasswordModal(false);
    setPendingAction(null);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Kho hàng</h2>
          <p className="text-slate-500">Quản lý danh sách sản phẩm và mức tồn kho.</p>
        </div>
        <div className="flex gap-2">
          {onPull && (
            <button 
              onClick={onPull}
              disabled={isPulling}
              className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 text-slate-600 rounded-xl hover:bg-slate-50 transition-all font-bold shadow-sm active:scale-95 disabled:opacity-50"
              title="Lấy dữ liệu mới nhất từ Google Sheets"
            >
              {isPulling ? <Loader2 size={20} className="animate-spin" /> : <RefreshCw size={20} />}
              <span className="hidden sm:inline">Cập nhật từ Cloud</span>
            </button>
          )}
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
            <select 
              className="pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 appearance-none min-w-[150px]"
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
            >
              <option value="All">Tất cả danh mục</option>
              {categories.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <button 
            onClick={() => setShowModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all font-bold shadow-lg shadow-indigo-100 active:scale-95"
          >
            <Plus size={20} />
            <span>Thêm sản phẩm</span>
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Sản phẩm</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Vị trí</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Danh mục</th>
                {showCostPrice && <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase text-right">Giá nhập</th>}
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase text-right">Giá bán</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase text-center">Tồn kho</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase text-right">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredProducts.map(p => (
                <tr key={p.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-lg bg-slate-100 flex items-center justify-center overflow-hidden shrink-0 border border-slate-200">
                        {p.imageUrl ? (
                           <img src={p.imageUrl} alt={p.name} className="w-full h-full object-cover" />
                        ) : (
                          <ImageIcon size={20} className="text-slate-400" />
                        )}
                      </div>
                      <div>
                        <p className="font-bold text-slate-900 leading-tight">{p.name}</p>
                        <p className="text-xs text-slate-500 mt-1 font-mono">SKU: {p.sku}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    {p.location ? (
                      <div className="flex items-center gap-1.5 text-slate-600">
                        <MapPin size={14} className="text-indigo-400" />
                        <span className="text-xs font-semibold">{p.location}</span>
                      </div>
                    ) : (
                      <span className="text-xs text-slate-300 italic">Chưa xác định</span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <span className="px-3 py-1 bg-slate-100 rounded-full text-slate-600 text-xs font-medium">
                      {p.category}
                    </span>
                  </td>
                  {showCostPrice && (
                    <td className="px-6 py-4 text-sm text-right font-medium text-slate-500">
                      {p.costPrice.toLocaleString()}đ
                    </td>
                  )}
                  <td className="px-6 py-4 text-sm text-right font-bold text-slate-900">
                    {p.salePrice.toLocaleString()}đ
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold ${
                      p.stock <= 5 ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'
                    }`}>
                      {p.stock}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-all">
                      <button 
                        onClick={() => { setEditingProduct(p); setShowModal(true); }}
                        className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                        title="Chỉnh sửa"
                      >
                        <Edit2 size={18} />
                      </button>
                      <button 
                        onClick={() => handleDelete(p.id)}
                        className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                        title="Xóa"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredProducts.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-slate-400">
                    <div className="flex flex-col items-center">
                      <Package size={48} className="mb-4 opacity-10" />
                      <p className="font-medium">Không tìm thấy sản phẩm nào</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <ProductModal 
          editingProduct={editingProduct} 
          categories={categories} 
          existingProducts={products}
          onClose={() => { setShowModal(false); setEditingProduct(null); }} 
          onSubmit={handleModalSubmit} 
        />
      )}

      {showPasswordModal && (
        <PasswordModal 
          correctPassword={adminPassword}
          onClose={() => { setShowPasswordModal(false); setPendingAction(null); }}
          onSuccess={handlePasswordSuccess}
        />
      )}
    </div>
  );
};

export default Inventory;
