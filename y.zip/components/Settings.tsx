
import React, { useState } from 'react';
import { 
  Save, 
  User, 
  Database, 
  Link as LinkIcon, 
  Zap, 
  Info, 
  Tag, 
  Plus, 
  X, 
  Check,
  Code,
  ChevronDown,
  ChevronUp,
  Copy,
  Wallet
} from 'lucide-react';
import { StoreInfo } from '../types';

interface SettingsProps {
  storeInfo: StoreInfo;
  setStoreInfo: (info: StoreInfo) => void;
}

const APPS_SCRIPT_CODE = `/**
 * SMART SHOP MANAGER - CLOUD SYNC SCRIPT V6.5 (PROFIT & COST UPDATE)
 * - Thêm cột totalCost (giá gốc) vào Transactions để tính lợi nhuận.
 */

function doGet(e) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var products = getSheetData(ss, "Products");
  var transactions = getSheetData(ss, "Transactions");
  var storeInfoData = getSheetData(ss, "StoreInfo");
  var passwordData = getSheetData(ss, "Passwords");

  var formattedProducts = products.map(function(p) {
    return {
      id: String(p.id || ""),
      sku: String(p.sku || ""),
      name: String(p.name || ""),
      category: String(p.category || ""),
      costPrice: Number(p.costPrice) || 0,
      salePrice: Number(p.salePrice) || 0,
      stock: Number(p.stock) || 0,
      imageUrl: String(p.imageUrl || ""),
      location: String(p.location || "")
    };
  });

  var formattedTransactions = transactions.map(function(t) {
    return {
      id: String(t.id || ""),
      timestamp: Number(t.timestamp) || Date.now(),
      total: Number(t.total) || 0,
      discountPercent: Number(t.discountPercent) || 0,
      finalAmount: Number(t.finalAmount) || 0,
      type: String(t.type || "sale"),
      totalCost: Number(t.totalCost) || 0,
      items: t.items ? JSON.parse(t.items) : []
    };
  });

  var storeInfo = {};
  if (storeInfoData.length > 0) {
    var s = storeInfoData[0];
    storeInfo = {
      name: String(s.name || ""),
      address: String(s.address || ""),
      phone: String(s.phone || ""),
      email: String(s.email || ""),
      categories: s.categories ? JSON.parse(s.categories) : [],
      showCostPrice: s.showCostPrice === true || s.showCostPrice === "true",
      bankName: String(s.bankName || ""),
      bankAccount: String(s.bankAccount || ""),
      bankAccountName: String(s.bankAccountName || "")
    };
  }
  
  // Lấy mật khẩu từ trang Passwords
  if (passwordData.length > 0) {
    storeInfo.stockPassword = String(passwordData[0].stockPassword || "");
    storeInfo.adminPassword = String(passwordData[0].adminPassword || "");
  }

  var result = {
    products: formattedProducts,
    transactions: formattedTransactions,
    storeInfo: storeInfo,
    serverTime: Date.now(),
    version: "6.5"
  };
  
  return ContentService.createTextOutput(JSON.stringify(result)).setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(30000); 
    
    var contents = e.postData.contents;
    var data = JSON.parse(contents);
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    
    // 1. SẢN PHẨM
    var productSheet = getOrCreateSheet(ss, "Products");
    var existingProducts = getSheetData(ss, "Products");
    var productMap = {};
    existingProducts.forEach(function(p) { productMap[String(p.id).trim()] = p; });
    
    if (data.deletedProductIds) {
      data.deletedProductIds.forEach(function(id) { delete productMap[String(id).trim()]; });
    }
    if (data.products) {
      data.products.forEach(function(p) { productMap[String(p.id).trim()] = p; });
    }
    
    if (productSheet.getLastRow() > 0) productSheet.getDataRange().clearContent();
    var productHeaders = ["id", "sku", "name", "category", "costPrice", "salePrice", "stock", "imageUrl", "location"];
    productSheet.appendRow(productHeaders);
    var finalProducts = Object.values(productMap);
    if (finalProducts.length > 0) {
      var productRows = finalProducts.map(function(p) {
        return [String(p.id), String(p.sku||""), String(p.name||""), String(p.category||""), Number(p.costPrice)||0, Number(p.salePrice)||0, Number(p.stock)||0, String(p.imageUrl||""), String(p.location||"")];
      });
      productSheet.getRange(2, 1, productRows.length, productHeaders.length).setValues(productRows);
    }

    // 2. GIAO DỊCH
    var transSheet = getOrCreateSheet(ss, "Transactions");
    var existingTrans = getSheetData(ss, "Transactions");
    var transMap = {};
    existingTrans.forEach(function(t) { transMap[String(t.id).trim()] = t; });
    if (data.transactions) {
      data.transactions.forEach(function(t) { transMap[String(t.id).trim()] = t; });
    }
    if (transSheet.getLastRow() > 0) transSheet.getDataRange().clearContent();
    var transHeaders = ["date_time", "id", "timestamp", "total", "discountPercent", "finalAmount", "totalCost", "type", "items"];
    transSheet.appendRow(transHeaders);
    var finalTrans = Object.values(transMap).sort(function(a,b) { return b.timestamp - a.timestamp; });
    if (finalTrans.length > 0) {
      var tz = ss.getSpreadsheetTimeZone();
      var transRows = finalTrans.map(function(t) {
        var formattedDate = Utilities.formatDate(new Date(Number(t.timestamp)), tz, "yyyy-MM-dd HH:mm:ss");
        return [formattedDate, String(t.id), Number(t.timestamp), Number(t.total)||0, Number(t.discountPercent)||0, Number(t.finalAmount)||0, Number(t.totalCost)||0, String(t.type||"sale"), typeof t.items === 'string' ? t.items : JSON.stringify(t.items||[])];
      });
      transSheet.getRange(2, 1, transRows.length, transHeaders.length).setValues(transRows);
    }

    // 3. CẤU HÌNH CỬA HÀNG
    if (data.storeInfo) {
      var storeSheet = getOrCreateSheet(ss, "StoreInfo");
      if (storeSheet.getLastRow() > 0) storeSheet.getDataRange().clearContent();
      storeSheet.appendRow(["name", "address", "phone", "email", "categories", "showCostPrice", "bankName", "bankAccount", "bankAccountName"]);
      storeSheet.appendRow([data.storeInfo.name, data.storeInfo.address, data.storeInfo.phone, data.storeInfo.email, JSON.stringify(data.storeInfo.categories || []), data.storeInfo.showCostPrice, data.storeInfo.bankName, data.storeInfo.bankAccount, data.storeInfo.bankAccountName]);
      
      // 4. MẬT KHẨU (Lưu vào trang riêng)
      var passSheet = getOrCreateSheet(ss, "Passwords");
      if (passSheet.getLastRow() > 0) passSheet.getDataRange().clearContent();
      passSheet.appendRow(["stockPassword", "adminPassword"]);
      passSheet.appendRow([data.storeInfo.stockPassword || "123", data.storeInfo.adminPassword || "admin"]);
    }

    // 5. NHẬT KÝ THAY ĐỔI (LOGS)
    if (data.logs && data.logs.length > 0) {
      var logSheet = getOrCreateSheet(ss, "Logs");
      if (logSheet.getLastRow() === 0) {
        logSheet.appendRow(["date_time", "productId", "productName", "action", "details"]);
      }
      var tz = ss.getSpreadsheetTimeZone();
      var logRows = data.logs.map(function(l) {
        var formattedDate = Utilities.formatDate(new Date(Number(l.timestamp)), tz, "yyyy-MM-dd HH:mm:ss");
        return [formattedDate, String(l.productId), String(l.productName), String(l.action), String(l.details)];
      });
      logSheet.getRange(logSheet.getLastRow() + 1, 1, logRows.length, 5).setValues(logRows);
    }

    return ContentService.createTextOutput("Sync Successful").setMimeType(ContentService.MimeType.TEXT);
  } catch (err) {
    return ContentService.createTextOutput("Error: " + err.toString()).setMimeType(ContentService.MimeType.TEXT);
  } finally {
    lock.releaseLock();
  }
}

function getSheetData(ss, sheetName) {
  var sheet = ss.getSheetByName(sheetName);
  if (!sheet) return [];
  var lastRow = sheet.getLastRow();
  if (lastRow <= 1) return [];
  var values = sheet.getDataRange().getValues();
  var headers = values.shift();
  return values.map(function(row) {
    var obj = {};
    headers.forEach(function(h, i) { obj[h] = row[i]; });
    return obj;
  });
}

function getOrCreateSheet(ss, name) {
  var sheet = ss.getSheetByName(name);
  if (!sheet) sheet = ss.insertSheet(name);
  return sheet;
}
`;

const Settings: React.FC<SettingsProps> = ({ storeInfo, setStoreInfo }) => {
  const [formData, setFormData] = useState<StoreInfo>(storeInfo);
  const [newCategory, setNewCategory] = useState('');
  const [saved, setSaved] = useState(false);
  const [showApiCode, setShowApiCode] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStoreInfo(formData);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const addCategory = () => {
    const trimmed = newCategory.trim();
    if (trimmed && !formData.categories.includes(trimmed)) {
      setFormData({
        ...formData,
        categories: [...formData.categories, trimmed]
      });
      setNewCategory('');
    }
  };

  const removeCategory = (cat: string) => {
    if (formData.categories.length <= 1) {
      alert("Cần có ít nhất một danh mục.");
      return;
    }
    if (confirm(`Bạn muốn xóa danh mục "${cat}"?`)) {
      setFormData({
        ...formData,
        categories: formData.categories.filter(c => c !== cat)
      });
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(APPS_SCRIPT_CODE);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8 animate-in fade-in duration-500 pb-12">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Cài đặt cửa hàng</h2>
        <p className="text-slate-500">Thông tin cơ bản, danh mục và kết nối dữ liệu đám mây.</p>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <form onSubmit={handleSubmit} className="p-8 space-y-8">
          <div className="space-y-6">
            <h4 className="font-bold text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-2">
              <User size={18} className="text-indigo-500" /> Thông tin cơ bản
            </h4>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-indigo-50 border border-indigo-100 rounded-2xl">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-white text-indigo-600 rounded-lg shadow-sm"><Tag size={18} /></div>
                  <div>
                    <p className="text-sm font-bold text-slate-900">Hiển thị giá nhập</p>
                    <p className="text-xs text-slate-500">Hiện cột giá nhập tại Kho và Bán hàng</p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" checked={formData.showCostPrice} onChange={e => setFormData({...formData, showCostPrice: e.target.checked})} />
                  <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                </label>
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Tên cửa hàng</label>
                <input type="text" className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 transition-all" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Địa chỉ</label>
                <textarea className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 transition-all" rows={2} value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})}></textarea>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Số điện thoại</label>
                  <input type="text" className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Email</label>
                  <input type="email" className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Mật khẩu Kho (Cho nhân viên)</label>
                  <input type="password" placeholder="Mật khẩu để nhân viên sửa kho..." className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500" value={formData.stockPassword || ''} onChange={e => setFormData({...formData, stockPassword: e.target.value})} />
                  <p className="text-[10px] text-slate-400 mt-1">Dùng để xác nhận khi thay đổi số lượng tồn kho.</p>
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Mật khẩu Hệ thống (Chỉ chủ shop)</label>
                  <input type="password" placeholder="Mật khẩu để vào Cài đặt..." className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-rose-500" value={formData.adminPassword || ''} onChange={e => setFormData({...formData, adminPassword: e.target.value})} />
                  <p className="text-[10px] text-rose-400 mt-1 font-bold">Dùng để vào mục Cài đặt này và đổi các mật khẩu khác.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <h4 className="font-bold text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-2">
              <Wallet size={18} className="text-emerald-500" /> Thông tin thanh toán (QR VietQR)
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Tên ngân hàng</label>
                <input 
                  type="text" 
                  placeholder="Ví dụ: MBBank, VCB, ICB..." 
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500" 
                  value={formData.bankName || ''} 
                  onChange={e => setFormData({...formData, bankName: e.target.value})} 
                />
                <p className="text-[10px] text-slate-400 mt-1">Dùng mã viết tắt (MB, VCB, TCB...) để tạo QR chính xác.</p>
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Số tài khoản</label>
                <input 
                  type="text" 
                  placeholder="Nhập số tài khoản..." 
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500" 
                  value={formData.bankAccount || ''} 
                  onChange={e => setFormData({...formData, bankAccount: e.target.value})} 
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-bold text-slate-700 mb-2">Tên chủ tài khoản</label>
                <input 
                  type="text" 
                  placeholder="NGUYEN VAN A" 
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 uppercase" 
                  value={formData.bankAccountName || ''} 
                  onChange={e => setFormData({...formData, bankAccountName: e.target.value.toUpperCase()})} 
                />
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <h4 className="font-bold text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-2">
              <Tag size={18} className="text-amber-500" /> Quản lý danh mục
            </h4>
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 space-y-4">
              <div className="flex gap-2">
                <input type="text" placeholder="Thêm danh mục mới..." className="flex-1 px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-amber-500" value={newCategory} onChange={e => setNewCategory(e.target.value)} onKeyPress={e => e.key === 'Enter' && (e.preventDefault(), addCategory())} />
                <button type="button" onClick={addCategory} className="px-6 py-3 bg-amber-500 text-white rounded-xl font-bold hover:bg-amber-600 transition-all shadow-lg shadow-amber-100"><Plus size={20} /></button>
              </div>
              <div className="flex flex-wrap gap-2">
                {formData.categories.map(cat => (
                  <div key={cat} className="flex items-center gap-2 px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-sm font-medium">
                    <span>{cat}</span>
                    <button type="button" onClick={() => removeCategory(cat)} className="text-slate-400 hover:text-rose-500"><X size={14} /></button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <h4 className="font-bold text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-2">
              <Database size={18} className="text-emerald-500" /> Kết nối Google Sheets
            </h4>
            <div className="flex items-center justify-between p-4 bg-slate-50 border border-slate-200 rounded-2xl">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${formData.autoSync ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-200 text-slate-500'}`}><Zap size={18} /></div>
                <div>
                  <p className="text-sm font-bold text-slate-900">Tự động đồng bộ (Push)</p>
                  <p className="text-xs text-slate-500">Lưu dữ liệu mỗi khi có thay đổi</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" checked={formData.autoSync} onChange={e => setFormData({...formData, autoSync: e.target.checked})} />
                <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
              </label>
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-2"><LinkIcon size={14} /> Google Script Web App URL</label>
              <input type="url" placeholder="https://script.google.com/macros/s/.../exec" className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 font-mono text-xs" value={formData.googleSheetsUrl || ''} onChange={e => setFormData({...formData, googleSheetsUrl: e.target.value})} />
            </div>
          </div>

          <div className="space-y-4 pt-2">
            <button type="button" onClick={() => setShowApiCode(!showApiCode)} className="w-full flex items-center justify-between p-4 bg-slate-50 border border-slate-200 rounded-2xl hover:bg-slate-100 transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-100 text-indigo-600 rounded-lg"><Code size={18} /></div>
                <span className="font-bold text-sm text-slate-800">Cấu hình API (V6.2 - NHẬT KÝ THAY ĐỔI)</span>
              </div>
              {showApiCode ? <ChevronUp size={20} className="text-slate-400" /> : <ChevronDown size={20} className="text-slate-400" />}
            </button>
            {showApiCode && (
              <div className="animate-in slide-in-from-top-2 duration-300 space-y-3">
                <div className="flex justify-between items-center px-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Mã nguồn đồng bộ Cloud V6.5</span>
                  <button type="button" onClick={copyToClipboard} className="flex items-center gap-1.5 text-xs font-bold text-indigo-600 hover:text-indigo-700">
                    {copied ? <Check size={14} /> : <Copy size={14} />} {copied ? 'Đã sao chép' : 'Sao chép mã'}
                  </button>
                </div>
                <pre className="p-4 bg-slate-900 text-slate-300 rounded-2xl text-[11px] overflow-x-auto font-mono max-h-[400px] overflow-y-auto">{APPS_SCRIPT_CODE}</pre>
                <div className="p-4 bg-blue-50 border border-blue-100 rounded-xl flex gap-3 text-blue-700 text-[11px]">
                  <Info className="text-blue-500 shrink-0" size={16} />
                  <div className="space-y-1">
                    <p><b>HƯỚNG DẪN CẬP NHẬT V6.5:</b> Để hỗ trợ xem chi phí giá gốc và tính lợi nhuận trên Google Sheets, bạn hãy cập nhật mã Script này. Mã mới sẽ thêm cột <b>"totalCost"</b> vào trang Transactions.</p>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="pt-4">
            <button type="submit" className={`w-full py-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all ${saved ? 'bg-emerald-500 text-white' : 'bg-indigo-600 text-white hover:bg-indigo-700'}`}>
              {saved ? <Check size={20} /> : <Save size={20} />} {saved ? 'ĐÃ LƯU THÀNH CÔNG' : 'LƯU CÀI ĐẶT'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Settings;
