
import React, { useState, useMemo } from 'react';
import { 
  ShoppingCart, 
  Search, 
  Plus, 
  Minus, 
  Trash2, 
  CreditCard, 
  Percent, 
  Printer,
  X,
  MapPin
} from 'lucide-react';
import { Product, CartItem, Transaction, StoreInfo } from '../types';

interface POSProps {
  products: Product[];
  onSale: (transaction: Transaction) => void;
  storeInfo: StoreInfo;
  search: string;
  showCostPrice?: boolean;
}

const POS: React.FC<POSProps> = ({ products, onSale, storeInfo, search, showCostPrice }) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [discountPercent, setDiscountPercent] = useState(0);
  const [showReceipt, setShowReceipt] = useState<Transaction | null>(null);

  const filteredProducts = useMemo(() => {
    return products.filter(p => 
      p.name.toLowerCase().includes(search.toLowerCase()) || 
      p.sku.toLowerCase().includes(search.toLowerCase()) ||
      (p.location && p.location.toLowerCase().includes(search.toLowerCase()))
    );
  }, [products, search]);

  const addToCart = (product: Product) => {
    if (product.stock <= 0) {
      alert('Sản phẩm này đã hết hàng!');
      return;
    }
    const existing = cart.find(item => item.id === product.id);
    if (existing) {
      if (existing.quantity >= product.stock) {
        alert('Không thể thêm nhiều hơn số lượng tồn kho!');
        return;
      }
      setCart(cart.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item));
    } else {
      setCart([...cart, { ...product, quantity: 1 }]);
    }
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(cart.map(item => {
      if (item.id === id) {
        const newQty = Math.max(0, item.quantity + delta);
        if (newQty > item.stock) {
          alert('Vượt quá số lượng tồn kho!');
          return item;
        }
        return { ...item, quantity: newQty };
      }
      return item;
    }).filter(item => item.quantity > 0));
  };

  const removeFromCart = (id: string) => {
    setCart(cart.filter(item => item.id !== id));
  };

  const totals = useMemo(() => {
    const subtotal = cart.reduce((acc, item) => acc + (item.salePrice * item.quantity), 0);
    const totalCost = cart.reduce((acc, item) => acc + (item.costPrice * item.quantity), 0);
    const discount = subtotal * (discountPercent / 100);
    const total = subtotal - discount;
    return { subtotal, discount, total, totalCost };
  }, [cart, discountPercent]);

  const handleCheckout = () => {
    if (cart.length === 0) return;
    const transaction: Transaction = {
      id: `TRX-${Date.now()}`,
      timestamp: Date.now(),
      items: [...cart],
      total: totals.subtotal,
      discountPercent: discountPercent,
      finalAmount: totals.total,
      type: 'sale',
      totalCost: totals.totalCost
    };
    onSale(transaction);
    setShowReceipt(transaction);
    setCart([]);
    setDiscountPercent(0);
  };

  // HÀM IN SỬ DỤNG IFRAME ẨN - KHÔNG NHẢY TRÌNH DUYỆT
  const handlePrint = () => {
    if (!showReceipt) return;

    // 1. Tạo một iframe ẩn
    const iframe = document.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    document.body.appendChild(iframe);

    const qrUrl = storeInfo.bankName && storeInfo.bankAccount 
      ? `https://img.vietqr.io/image/${storeInfo.bankName}-${storeInfo.bankAccount}-compact2.png?amount=${showReceipt.finalAmount}&addInfo= DOI TIEN MAT&accountName=${encodeURIComponent(storeInfo.bankAccountName || '')}`
      : null;

    const receiptHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Hóa đơn #${showReceipt.id}</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
        <style>
          body { 
            font-family: 'Inter', sans-serif; 
            padding: 20px; 
            background: white; 
            color: black;
            width: 80mm; /* Giả định in giấy in nhiệt 80mm phổ biến */
            margin: 0 auto;
          }
          .dashed-line { border-top: 1px dashed black; margin: 15px 0; }
          @page { margin: 0; size: auto; }
          @media print {
            body { padding: 10px; }
          }
        </style>
      </head>
      <body>
        <div class="text-center mb-6">
          <h1 class="text-xl font-bold uppercase">${storeInfo.name}</h1>
          <p class="text-[10px] text-gray-600 mt-1">${storeInfo.address}</p>
          <p class="text-[10px] font-bold">ĐT: ${storeInfo.phone}</p>
        </div>

        <div class="flex justify-between text-[10px] mb-1">
          <span class="font-bold">HĐ: #${showReceipt.id}</span>
          <span>${new Date(showReceipt.timestamp).toLocaleString('vi-VN')}</span>
        </div>

        <div class="dashed-line"></div>

        <table class="w-full text-[10px] mb-4">
          <thead>
            <tr class="border-b border-black">
              <th class="text-left pb-1">Tên</th>
              <th class="text-center pb-1">SL</th>
              <th class="text-right pb-1">Đơn giá</th>
              <th class="text-right pb-1">T.Tiền</th>
            </tr>
          </thead>
          <tbody>
            ${showReceipt.items.map(item => `
              <tr>
                <td class="py-1 pr-1">${item.name}</td>
                <td class="py-1 text-center">${item.quantity}</td>
                <td class="py-1 text-right">${item.salePrice.toLocaleString()}</td>
                <td class="py-1 text-right font-bold">${(item.quantity * item.salePrice).toLocaleString()}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <div class="dashed-line"></div>

        <div class="space-y-1 text-[10px]">
          <div class="flex justify-between">
            <span>Tạm tính:</span>
            <span>${showReceipt.total.toLocaleString()}</span>
          </div>
          <div class="flex justify-between">
            <span>Giảm giá:</span>
            <span>- ${(showReceipt.total - showReceipt.finalAmount).toLocaleString()}</span>
          </div>
          <div class="flex justify-between text-sm font-bold pt-1">
            <span>TỔNG CỘNG:</span>
            <span>${showReceipt.finalAmount.toLocaleString()} đ</span>
          </div>
        </div>

        ${qrUrl ? `
          <div class="text-center mt-6" style="min-height: 160px;">
            <p class="text-[9px] font-bold mb-2 uppercase">Quét mã để thanh toán</p>
            <img src="${qrUrl}" class="w-40 h-40 mx-auto" alt="QR Payment" referrerpolicy="no-referrer" />
            <p class="text-[8px] mt-1">${storeInfo.bankName} - ${storeInfo.bankAccount}</p>
            <p class="text-[8px] font-bold">${storeInfo.bankAccountName}</p>
          </div>
        ` : ''}

        <div class="text-center mt-8 text-[9px] italic">
          <p>Cảm ơn quý khách!</p>
          <p>Hẹn gặp lại.</p>
        </div>
      </body>
      </html>
    `;

    const doc = iframe.contentWindow?.document;
    if (doc) {
      doc.open();
      doc.write(receiptHtml);
      doc.close();

      // Đợi tất cả tài nguyên (ảnh, font, css) nạp xong rồi mới in
      iframe.contentWindow?.addEventListener('load', () => {
        // Thêm một chút delay nhỏ để đảm bảo render hoàn tất
        setTimeout(() => {
          iframe.contentWindow?.focus();
          iframe.contentWindow?.print();
          
          // Xóa iframe sau khi in xong
          setTimeout(() => {
            document.body.removeChild(iframe);
          }, 1000);
        }, 300);
      });

      // Trường hợp load event không kích hoạt (hiếm gặp)
      setTimeout(() => {
        if (document.body.contains(iframe)) {
          iframe.contentWindow?.focus();
          iframe.contentWindow?.print();
          setTimeout(() => {
            if (document.body.contains(iframe)) document.body.removeChild(iframe);
          }, 1000);
        }
      }, 3000);
    }
  };

  const ReceiptModal = ({ transaction }: { transaction: Transaction }) => (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl overflow-hidden animate-in fade-in zoom-in-95">
        <div className="p-8 bg-white text-slate-900">
          <div className="text-center mb-6">
             <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Printer size={32} />
             </div>
             <h3 className="text-xl font-bold">Thanh toán thành công!</h3>
             <p className="text-slate-500 text-sm mt-1">Hóa đơn #{transaction.id}</p>
          </div>

          <div className="bg-slate-50 rounded-xl p-4 space-y-3 mb-6">
            <div className="flex justify-between text-sm">
              <span className="text-slate-500">Tổng tiền hàng:</span>
              <span className="font-medium">{transaction.total.toLocaleString()}đ</span>
            </div>
            <div className="flex justify-between text-sm text-rose-600">
              <span>Giảm giá:</span>
              <span>-{(transaction.total - transaction.finalAmount).toLocaleString()}đ</span>
            </div>
            <div className="pt-2 border-t border-slate-200 flex justify-between font-bold text-lg text-indigo-600">
              <span>Tổng cộng:</span>
              <span>{transaction.finalAmount.toLocaleString()}đ</span>
            </div>
          </div>

          {storeInfo.bankName && storeInfo.bankAccount && (
            <div className="mb-6 p-4 bg-emerald-50 border border-emerald-100 rounded-2xl text-center">
              <p className="text-[10px] font-bold text-emerald-700 uppercase mb-2">Mã QR Thanh toán</p>
              <img 
                src={`https://img.vietqr.io/image/${storeInfo.bankName}-${storeInfo.bankAccount}-compact2.png?amount=${transaction.finalAmount}&addInfo=Thanh toan HD ${transaction.id}&accountName=${encodeURIComponent(storeInfo.bankAccountName || '')}`} 
                className="w-48 h-48 mx-auto rounded-lg shadow-sm border border-white"
                alt="QR Payment"
              />
              <p className="text-[10px] text-emerald-600 mt-2 font-medium">{storeInfo.bankName} - {storeInfo.bankAccount}</p>
            </div>
          )}
          
          <div className="flex gap-3">
            <button 
              onClick={handlePrint}
              className="flex-1 py-4 bg-indigo-600 text-white rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-indigo-700 active:scale-95 transition-all shadow-lg shadow-indigo-100"
            >
              <Printer size={20} />
              In hóa đơn
            </button>
            <button 
              onClick={() => setShowReceipt(null)}
              className="px-6 py-4 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 transition-all"
            >
              Đóng
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex h-full gap-6 animate-in fade-in duration-500 overflow-hidden">
      {/* Products Grid */}
      <div className="flex-1 overflow-y-auto space-y-6 pr-2">
        <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredProducts.map(p => (
            <button 
              key={p.id}
              onClick={() => addToCart(p)}
              disabled={p.stock <= 0}
              className={`flex flex-col text-left bg-white border border-slate-200 rounded-2xl p-3 shadow-sm hover:shadow-md hover:-translate-y-1 transition-all group ${p.stock <= 0 ? 'opacity-50 grayscale' : ''}`}
            >
              <div className="relative aspect-square rounded-xl bg-slate-100 mb-3 overflow-hidden">
                <img src={p.imageUrl} alt={p.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                {p.stock <= 5 && p.stock > 0 && (
                  <div className="absolute top-2 right-2 bg-amber-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded uppercase shadow-sm">Sắp hết</div>
                )}
                {p.stock <= 0 && (
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                    <span className="text-white font-bold text-xs uppercase bg-red-600 px-2 py-1 rounded">Hết hàng</span>
                  </div>
                )}
              </div>
              <h4 className="font-bold text-slate-900 text-sm mb-1 truncate w-full">{p.name}</h4>
              
              <div className="flex flex-wrap items-center gap-1.5 mb-3">
                <span className="text-[10px] font-medium text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                  {p.category}
                </span>
                {p.location && (
                  <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded flex items-center gap-0.5">
                    <MapPin size={10} />
                    {p.location}
                  </span>
                )}
              </div>

              <div className="flex items-center justify-between mt-auto">
                <div className="flex flex-col">
                  <span className="font-bold text-indigo-600">{p.salePrice.toLocaleString()}đ</span>
                  {showCostPrice && (
                    <span className="text-[9px] text-slate-400 italic">Vốn: {p.costPrice.toLocaleString()}đ</span>
                  )}
                </div>
                <span className={`text-[10px] font-bold ${p.stock <= 5 ? 'text-amber-600' : 'text-slate-400'}`}>
                  Kho: {p.stock}
                </span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Cart Panel */}
      <div className="w-96 flex flex-col bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden no-print">
        <div className="p-4 border-b border-slate-100 flex items-center gap-2">
          <div className="w-8 h-8 bg-indigo-50 text-indigo-600 rounded-lg flex items-center justify-center shrink-0">
            <ShoppingCart size={18} />
          </div>
          <h3 className="font-bold">Giỏ hàng ({cart.length})</h3>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {cart.length > 0 ? (
            cart.map(item => (
              <div key={item.id} className="flex gap-3 items-start animate-in slide-in-from-right-4 duration-200">
                <img src={item.imageUrl} alt={item.name} className="w-12 h-12 rounded-lg object-cover shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-sm truncate">{item.name}</p>
                  <p className="text-xs text-indigo-600 font-medium">{item.salePrice.toLocaleString()}đ</p>
                  <div className="flex items-center gap-3 mt-2">
                    <div className="flex items-center border border-slate-200 rounded-lg overflow-hidden">
                      <button onClick={() => updateQuantity(item.id, -1)} className="p-1 hover:bg-slate-50"><Minus size={14} /></button>
                      <span className="px-3 text-xs font-bold">{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.id, 1)} className="p-1 hover:bg-slate-50"><Plus size={14} /></button>
                    </div>
                    <button onClick={() => removeFromCart(item.id)} className="text-rose-500 hover:text-rose-600"><Trash2 size={16} /></button>
                  </div>
                </div>
                <p className="text-sm font-bold">{(item.salePrice * item.quantity).toLocaleString()}đ</p>
              </div>
            ))
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 opacity-50">
              <ShoppingCart size={48} className="mb-2" />
              <p>Chưa có sản phẩm nào</p>
            </div>
          )}
        </div>

        <div className="p-6 bg-slate-50 border-t border-slate-200 space-y-4">
          <div className="space-y-2 text-sm">
            <div className="flex justify-between text-slate-500">
              <span>Tạm tính</span>
              <span>{totals.subtotal.toLocaleString()}đ</span>
            </div>
            <div className="flex justify-between items-center text-rose-500">
              <div className="flex items-center gap-1">
                <Percent size={14} />
                <span>Giảm giá</span>
              </div>
              <input 
                type="number" 
                max="100" 
                min="0"
                className="w-16 h-8 px-2 bg-white border border-slate-200 rounded-lg text-right font-bold text-xs"
                value={discountPercent}
                onChange={e => setDiscountPercent(Number(e.target.value))}
              />
            </div>
            <div className="flex justify-between text-lg font-bold text-slate-900 pt-2 border-t border-slate-200">
              <span>Tổng cộng</span>
              <span>{totals.total.toLocaleString()}đ</span>
            </div>
          </div>
          
          <button 
            disabled={cart.length === 0}
            onClick={handleCheckout}
            className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-indigo-700 disabled:bg-slate-300 disabled:cursor-not-allowed transition-all shadow-lg shadow-indigo-200"
          >
            <CreditCard size={20} />
            THANH TOÁN
          </button>
        </div>
      </div>

      {showReceipt && <ReceiptModal transaction={showReceipt} />}
    </div>
  );
};

export default POS;
