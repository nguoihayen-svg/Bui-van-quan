
import React, { useState, useMemo } from 'react';
import { 
  History, 
  Calendar, 
  FileText, 
  ChevronDown, 
  Download
} from 'lucide-react';
import { Transaction } from '../types';

interface HistoryProps {
  transactions: Transaction[];
}

const HistoryView: React.FC<HistoryProps> = ({ transactions }) => {
  const [selectedTx, setSelectedTx] = useState<string | null>(null);
  
  // Trạng thái lọc ngày (Mặc định 30 ngày qua)
  const [startDate, setStartDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 30);
    return d.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState(() => {
    return new Date().toISOString().split('T')[0];
  });

  const formatCurrency = (val: number) => 
    new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(val);

  // Lọc giao dịch theo ngày
  const filteredTransactions = useMemo(() => {
    const start = new Date(startDate);
    start.setHours(0, 0, 0, 0);
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999);

    return transactions.filter(t => {
      const tDate = new Date(t.timestamp);
      return tDate >= start && tDate <= end;
    }).sort((a, b) => b.timestamp - a.timestamp);
  }, [transactions, startDate, endDate]);

  // Xuất file Excel (thực tế là CSV có BOM để Excel hiển thị đúng tiếng Việt)
  const exportToExcel = () => {
    if (filteredTransactions.length === 0) {
      alert("Không có dữ liệu trong khoảng thời gian đã chọn để xuất!");
      return;
    }

    const headers = ["Mã giao dịch", "Thời gian", "Loại", "Tổng mặt hàng", "Chi tiết sản phẩm", "Tạm tính", "Giảm giá (%)", "Thành tiền", "Giá vốn", "Lợi nhuận"];
    const rows = filteredTransactions.map(t => {
      const itemsList = t.items.map(i => `${i.name} (x${i.quantity})`).join("; ");
      const totalCost = t.totalCost !== undefined ? t.totalCost : t.items.reduce((sum, item) => sum + (item.costPrice * item.quantity), 0);
      return [
        t.id,
        new Date(t.timestamp).toLocaleString('vi-VN'),
        t.type === 'sale' ? 'Bán hàng' : 'Nhập hàng',
        t.items.length,
        itemsList,
        t.total,
        t.discountPercent,
        t.finalAmount,
        totalCost,
        t.finalAmount - totalCost
      ];
    });

    // Thêm ký tự BOM (\uFEFF) ở đầu để Excel nhận diện UTF-8
    const csvContent = "\uFEFF" + [
      headers.join(","),
      ...rows.map(r => r.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(","))
    ].join("\n");

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `Bao_cao_giao_dich_${startDate}_den_${endDate}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-10">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Lịch sử giao dịch</h2>
          <p className="text-slate-500">Xem lại các hóa đơn và xuất báo cáo dữ liệu bảng tính.</p>
        </div>

        <div className="flex flex-wrap items-center gap-3 bg-white p-2 rounded-2xl border border-slate-200 shadow-sm no-print">
          <div className="flex items-center gap-2 px-2 border-r border-slate-100 pr-4">
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
              <input 
                type="date" 
                className="pl-9 pr-3 py-2 bg-slate-50 border-none rounded-xl text-xs font-bold focus:ring-2 focus:ring-indigo-500 outline-none"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>
            <span className="text-slate-400 text-xs font-bold">đến</span>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
              <input 
                type="date" 
                className="pl-9 pr-3 py-2 bg-slate-50 border-none rounded-xl text-xs font-bold focus:ring-2 focus:ring-indigo-500 outline-none"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
          </div>
          
          <button 
            onClick={exportToExcel}
            className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition-all font-bold text-xs shadow-lg shadow-emerald-100 active:scale-95"
          >
            <Download size={16} />
            XUẤT EXCEL
          </button>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Mã giao dịch</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Thời gian</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Sản phẩm</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase text-right">Thành tiền</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase text-right">Chi tiết</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTransactions.map(t => (
                <React.Fragment key={t.id}>
                  <tr className="hover:bg-slate-50/50 transition-colors group">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600">
                          <FileText size={16} />
                        </div>
                        <span className="font-mono text-xs font-bold">{t.id}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-500">
                      {new Date(t.timestamp).toLocaleString('vi-VN')}
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600">
                      {t.items.length} mặt hàng
                    </td>
                    <td className="px-6 py-4 text-sm text-right font-bold text-slate-900">
                      {formatCurrency(t.finalAmount)}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button 
                        onClick={() => setSelectedTx(selectedTx === t.id ? null : t.id)}
                        className={`p-2 hover:bg-slate-100 rounded-lg transition-transform ${selectedTx === t.id ? 'rotate-180' : ''}`}
                      >
                        <ChevronDown size={18} />
                      </button>
                    </td>
                  </tr>
                  {selectedTx === t.id && (
                    <tr className="bg-slate-50">
                      <td colSpan={5} className="px-6 py-4 animate-in slide-in-from-top-2 duration-200">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                           <div>
                             <h5 className="text-xs font-bold text-slate-400 uppercase mb-4 tracking-wider">Danh sách sản phẩm</h5>
                             <div className="space-y-3">
                               {t.items.map(item => (
                                 <div key={item.id} className="flex justify-between text-sm">
                                   <span>{item.name} <span className="text-slate-400 font-medium">x{item.quantity}</span></span>
                                   <span className="font-bold">{(item.quantity * item.salePrice).toLocaleString()}đ</span>
                                 </div>
                               ))}
                             </div>
                           </div>
                           <div className="border-l border-slate-100 pl-8 flex flex-col justify-end text-right space-y-2">
                              <p className="text-sm text-slate-500">Tạm tính: {t.total.toLocaleString()}đ</p>
                              <p className="text-sm text-rose-500">Giảm giá: {t.discountPercent}%</p>
                              <p className="text-xl font-bold text-indigo-600">Tổng cộng: {t.finalAmount.toLocaleString()}đ</p>
                           </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
              {filteredTransactions.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-slate-400">
                    <History size={48} className="mx-auto mb-2 opacity-10" />
                    <p>Không tìm thấy giao dịch nào trong khoảng thời gian này</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default HistoryView;
