
import React, { useMemo, useState } from 'react';
import { 
  TrendingUp, 
  Package, 
  Wallet, 
  AlertCircle,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  Banknote,
  RefreshCw,
  Loader2
} from 'lucide-react';
import { CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, XAxis, YAxis } from 'recharts';
import { Product, Transaction } from '../types';

interface DashboardProps {
  products: Product[];
  transactions: Transaction[];
  onPull?: () => void;
  isPulling?: boolean;
}

const Dashboard: React.FC<DashboardProps> = ({ products, transactions, onPull, isPulling }) => {
  // Mặc định lọc 7 ngày gần nhất
  const [startDate, setStartDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 7);
    return d.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState(() => {
    return new Date().toISOString().split('T')[0];
  });

  const stats = useMemo(() => {
    const start = new Date(startDate);
    start.setHours(0, 0, 0, 0);
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999);

    // Lọc giao dịch trong khoảng ngày
    const filteredTransactions = transactions.filter(t => {
      const tDate = new Date(t.timestamp);
      return tDate >= start && tDate <= end;
    });

    const totalRevenue = filteredTransactions.reduce((acc, t) => acc + t.finalAmount, 0);
    
    // Tính lợi nhuận: Doanh thu thực tế (sau giảm giá) - Giá vốn hàng bán (COGS)
    const totalProfit = filteredTransactions.reduce((acc, t) => {
      const transactionCOGS = t.totalCost !== undefined ? t.totalCost : t.items.reduce((sum, item) => sum + (item.costPrice * item.quantity), 0);
      return acc + (t.finalAmount - transactionCOGS);
    }, 0);

    const totalStockValue = products.reduce((acc, p) => acc + (p.costPrice * p.stock), 0);
    const lowStockItems = products.filter(p => p.stock <= 5);
    
    // Tạo dữ liệu cho biểu đồ dựa trên khoảng ngày đã chọn
    const dayDiff = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
    const revenueByDay = [];
    
    for (let i = 0; i <= dayDiff; i++) {
      const currentDay = new Date(start);
      currentDay.setDate(start.getDate() + i);
      const dateStr = currentDay.toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit' });
      
      const amount = filteredTransactions
        .filter(t => new Date(t.timestamp).toLocaleDateString('vi-VN') === currentDay.toLocaleDateString('vi-VN'))
        .reduce((acc, t) => acc + t.finalAmount, 0);
      
      revenueByDay.push({ day: dateStr, amount });
    }

    return { 
      totalRevenue, 
      totalProfit,
      totalStockValue, 
      lowStockItems, 
      revenueByDay, 
      orderCount: filteredTransactions.length 
    };
  }, [products, transactions, startDate, endDate]);

  const StatCard = ({ title, value, icon: Icon, color, trend }: any) => (
    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
      <div className="flex justify-between items-start mb-4">
        <div className={`p-3 rounded-xl ${color}`}>
          <Icon size={24} />
        </div>
        {trend && (
          <div className={`flex items-center gap-1 text-sm font-medium ${trend > 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
            {trend > 0 ? <ArrowUpRight size={16} /> : <ArrowDownRight size={16} />}
            {Math.abs(trend)}%
          </div>
        )}
      </div>
      <p className="text-slate-500 text-sm font-medium mb-1">{title}</p>
      <h3 className="text-2xl font-bold">{value}</h3>
    </div>
  );

  const formatCurrency = (val: number) => 
    new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(val);

  const setPreset = (days: number) => {
    const end = new Date();
    const start = new Date();
    start.setDate(end.getDate() - days);
    setStartDate(start.toISOString().split('T')[0]);
    setEndDate(end.toISOString().split('T')[0]);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Tổng quan</h2>
          <p className="text-slate-500">Báo cáo hoạt động kinh doanh theo thời gian.</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-3 bg-white p-2 rounded-2xl border border-slate-200 shadow-sm">
          {onPull && (
            <button 
              onClick={onPull}
              disabled={isPulling}
              className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold text-slate-600 hover:bg-slate-50 rounded-lg transition-colors border-r border-slate-100 pr-4 disabled:opacity-50"
            >
              {isPulling ? <Loader2 size={14} className="animate-spin" /> : <RefreshCw size={14} />}
              <span>Làm mới</span>
            </button>
          )}
          <div className="flex items-center gap-2 px-2 border-r border-slate-100 pr-4">
            <button onClick={() => setPreset(1)} className="px-3 py-1.5 text-xs font-bold hover:bg-slate-50 rounded-lg transition-colors text-slate-600">Hôm nay</button>
            <button onClick={() => setPreset(7)} className="px-3 py-1.5 text-xs font-bold hover:bg-slate-50 rounded-lg transition-colors text-slate-600">7 ngày</button>
            <button onClick={() => setPreset(30)} className="px-3 py-1.5 text-xs font-bold hover:bg-slate-50 rounded-lg transition-colors text-slate-600">30 ngày</button>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
              <input 
                type="date" 
                className="pl-9 pr-3 py-2 bg-slate-50 border-none rounded-xl text-xs font-bold focus:ring-2 focus:ring-indigo-500 outline-none"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>
            <span className="text-slate-400 text-xs font-bold">đến</span>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
              <input 
                type="date" 
                className="pl-9 pr-3 py-2 bg-slate-50 border-none rounded-xl text-xs font-bold focus:ring-2 focus:ring-indigo-500 outline-none"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
        <StatCard 
          title="Doanh thu kỳ này" 
          value={formatCurrency(stats.totalRevenue)} 
          icon={TrendingUp} 
          color="bg-emerald-50 text-emerald-600"
        />
        <StatCard 
          title="Lợi nhuận gộp" 
          value={formatCurrency(stats.totalProfit)} 
          icon={Banknote} 
          color="bg-indigo-50 text-indigo-600"
        />
        <StatCard 
          title="Giá trị tồn kho" 
          value={formatCurrency(stats.totalStockValue)} 
          icon={Package} 
          color="bg-blue-50 text-blue-600"
        />
        <StatCard 
          title="Số đơn hàng" 
          value={stats.orderCount} 
          icon={Wallet} 
          color="bg-slate-50 text-slate-600"
        />
        <StatCard 
          title="Hàng sắp hết" 
          value={stats.lowStockItems.length} 
          icon={AlertCircle} 
          color="bg-amber-50 text-amber-600"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex justify-between items-center mb-6">
            <h4 className="text-lg font-bold">Xu hướng doanh số</h4>
            <div className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
              {new Date(startDate).toLocaleDateString('vi-VN')} - {new Date(endDate).toLocaleDateString('vi-VN')}
            </div>
          </div>
          <div className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats.revenueByDay}>
                <defs>
                  <linearGradient id="colorAmount" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="day" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 600}} 
                  interval={stats.revenueByDay.length > 15 ? Math.floor(stats.revenueByDay.length / 7) : 0}
                />
                <YAxis 
                  hide={stats.totalRevenue === 0}
                  axisLine={false}
                  tickLine={false}
                  tick={{fill: '#94a3b8', fontSize: 10}}
                  tickFormatter={(val) => `${(val / 1000000).toFixed(0)}tr`}
                />
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', padding: '12px' }}
                  formatter={(value: number) => [formatCurrency(value), 'Doanh thu']}
                  labelStyle={{ fontWeight: 'bold', marginBottom: '4px', color: '#1e293b' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="amount" 
                  stroke="#4f46e5" 
                  strokeWidth={3} 
                  fillOpacity={1} 
                  fill="url(#colorAmount)" 
                  animationDuration={1500}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col">
          <h4 className="text-lg font-bold mb-4">Mặt hàng cần chú ý</h4>
          <div className="flex-1 space-y-4">
            {stats.lowStockItems.length > 0 ? (
              stats.lowStockItems.slice(0, 6).map(p => (
                <div key={p.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl hover:bg-slate-100 transition-colors group">
                  <div className="flex items-center gap-3">
                    <img src={p.imageUrl} alt={p.name} className="w-10 h-10 rounded-lg object-cover shadow-sm group-hover:scale-110 transition-transform" />
                    <div>
                      <p className="text-sm font-bold truncate w-32 text-slate-900">{p.name}</p>
                      <p className="text-[10px] text-slate-500 font-medium">Tồn kho: <span className="text-rose-600 font-bold">{p.stock}</span></p>
                    </div>
                  </div>
                  <div className="text-[9px] font-bold text-amber-700 px-2 py-1 bg-amber-100 rounded-md uppercase tracking-wider">
                    Sắp hết
                  </div>
                </div>
              ))
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-slate-400">
                <Package size={48} className="mb-2 opacity-20" />
                <p className="text-sm font-medium">Kho hàng ổn định!</p>
              </div>
            )}
          </div>
          {stats.lowStockItems.length > 6 && (
            <button className="mt-4 text-xs text-indigo-600 font-bold hover:underline uppercase tracking-widest">
              Xem thêm {stats.lowStockItems.length - 6} mặt hàng
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
