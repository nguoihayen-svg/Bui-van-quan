
import { Product, Transaction, StoreInfo, SyncPayload, LogEntry } from "../types";

export const syncToGoogleSheets = async (
  url: string, 
  products: Product[], 
  transactions: Transaction[], 
  storeInfo: StoreInfo,
  deletedProductIds: string[] = [],
  logs: LogEntry[] = []
) => {
  if (!url) throw new Error("Chưa cấu hình URL Google Web App");

  // Chuẩn hóa dữ liệu để đảm bảo không có giá trị undefined làm hỏng JSON
  const payload: SyncPayload = {
    action: 'push',
    products: products.map(p => ({
      id: String(p.id),
      sku: String(p.sku || ""),
      name: String(p.name || ""),
      category: String(p.category || ""),
      costPrice: Number(p.costPrice) || 0,
      salePrice: Number(p.salePrice) || 0,
      stock: Number(p.stock) || 0,
      imageUrl: String(p.imageUrl || ""),
      location: String(p.location || "")
    })),
    transactions: transactions.map(t => ({
      id: String(t.id),
      timestamp: Number(t.timestamp),
      total: Number(t.total) || 0,
      discountPercent: Number(t.discountPercent) || 0,
      finalAmount: Number(t.finalAmount) || 0,
      type: t.type || 'sale',
      items: t.items || [],
      totalCost: Number(t.totalCost) || 0
    })),
    storeInfo: {
      name: String(storeInfo.name || ""),
      address: String(storeInfo.address || ""),
      phone: String(storeInfo.phone || ""),
      email: String(storeInfo.email || ""),
      stockPassword: String(storeInfo.stockPassword || ""),
      adminPassword: String(storeInfo.adminPassword || ""),
      categories: storeInfo.categories || []
    },
    logs: logs.map(l => ({
      id: String(l.id),
      timestamp: Number(l.timestamp),
      productId: String(l.productId),
      productName: String(l.productName),
      action: String(l.action),
      details: String(l.details)
    })),
    deletedProductIds: Array.isArray(deletedProductIds) ? deletedProductIds.map(id => String(id)) : [],
    timestamp: new Date().toISOString()
  };

  try {
    // Chế độ no-cors yêu cầu body phải là text/plain hoặc url-encoded để không kích hoạt Preflight
    await fetch(url, {
      method: 'POST',
      mode: 'no-cors', 
      headers: { 'Content-Type': 'text/plain' },
      body: JSON.stringify(payload)
    });
    return true;
  } catch (error) {
    console.error("Push Error Details:", error);
    throw error;
  }
};

export const fetchFromGoogleSheets = async (url: string) => {
  if (!url) throw new Error("Chưa cấu hình URL Google Web App");

  try {
    const response = await fetch(`${url}?action=pull`);
    if (!response.ok) throw new Error("Không thể tải dữ liệu từ Cloud");
    
    const data = await response.json();
    return data as { 
      products: Product[], 
      transactions: Transaction[], 
      storeInfo?: Partial<StoreInfo> 
    };
  } catch (error) {
    console.error("Pull Error:", error);
    throw error;
  }
};
