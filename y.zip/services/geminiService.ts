
import { GoogleGenAI } from "@google/genai";
import { Product, Transaction } from "../types";

export const getAIInsights = async (products: Product[], transactions: Transaction[]) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const salesContext = transactions.slice(-20).map(t => ({
    time: new Date(t.timestamp).toLocaleDateString('vi-VN'),
    total: t.finalAmount,
    items: t.items.map(i => `${i.name} (x${i.quantity})`).join(', ')
  }));

  const inventoryContext = products.map(p => ({
    name: p.name,
    stock: p.stock,
    price: p.salePrice
  }));

  const prompt = `
    Bạn là một chuyên gia phân tích kinh doanh cho cửa hàng bán lẻ đồ công nghệ "SmartShop Manager".
    Dựa trên dữ liệu dưới đây, hãy đưa ra báo cáo phân tích bằng tiếng Việt.
    
    Dữ liệu tồn kho: ${JSON.stringify(inventoryContext)}
    Dữ liệu 20 giao dịch gần đây: ${JSON.stringify(salesContext)}

    Yêu cầu báo cáo bao gồm:
    1. Tổng quan tình hình bán hàng (tốt/chậm).
    2. Các mặt hàng bán chạy và mặt hàng tồn kho lâu.
    3. Gợi ý chương trình khuyến mãi cụ thể.
    4. Cảnh báo rủi ro về tồn kho (hết hàng hoặc quá nhiều hàng).
    
    Hãy trả về văn bản định dạng Markdown chuyên nghiệp, dễ đọc.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini AI Error:", error);
    return "Lỗi khi kết nối với Gemini AI. Vui lòng kiểm tra lại cấu hình.";
  }
};
