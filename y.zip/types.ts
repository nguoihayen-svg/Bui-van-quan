
export type Category = string;

export interface Product {
  id: string;
  name: string;
  category: Category;
  costPrice: number;
  salePrice: number;
  stock: number;
  imageUrl: string;
  sku: string;
  location: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Transaction {
  id: string;
  timestamp: number;
  items: CartItem[];
  total: number;
  discountPercent: number;
  finalAmount: number;
  type: 'sale' | 'purchase';
  totalCost: number;
}

export interface StoreInfo {
  name: string;
  address: string;
  phone: string;
  email: string;
  website: string;
  categories: string[];
  googleSheetsUrl?: string;
  stockPassword?: string;
  adminPassword?: string;
  lastSync?: number;
  autoSync?: boolean;
  showCostPrice?: boolean;
  bankName?: string;
  bankAccount?: string;
  bankAccountName?: string;
}

export interface DashboardStats {
  totalRevenue: number;
  totalProfit: number;
  totalStockValue: number;
  lowStockItems: Product[];
  revenueByDay: { day: string; amount: number }[];
}

export interface LogEntry {
  id: string;
  timestamp: number;
  productId: string;
  productName: string;
  action: string;
  details: string;
}

export interface SyncPayload {
  action: 'push';
  products: Product[];
  transactions: Transaction[];
  storeInfo: any;
  logs?: LogEntry[];
  deletedProductIds?: string[];
  timestamp: string;
}
