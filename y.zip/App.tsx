
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { 
  LayoutDashboard, 
  Package, 
  ShoppingCart, 
  History, 
  Settings as SettingsIcon, 
  Menu,
  X,
  Search,
  LogOut,
  Cloud,
  DownloadCloud,
  Loader2,
  Wifi,
  CloudUpload
} from 'lucide-react';
import { Product, Transaction, StoreInfo, LogEntry } from './types';
import { INITIAL_PRODUCTS, DEFAULT_STORE_INFO } from './constants';
import Dashboard from './components/Dashboard';
import Inventory, { PasswordModal } from './components/Inventory';
import POS from './components/POS';
import HistoryView from './components/History';
import Settings from './components/Settings';
import { syncToGoogleSheets, fetchFromGoogleSheets } from './services/syncService';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [globalSearch, setGlobalSearch] = useState('');
  
  // Bảo vệ tab Cài đặt
  const [showSettingsLock, setShowSettingsLock] = useState(false);
  const [isSettingsUnlocked, setIsSettingsUnlocked] = useState(false);

  // Trạng thái đồng bộ hiển thị (Chỉ hiện khi nhấn nút)
  const [isSyncing, setIsSyncing] = useState(false); 
  const [isPulling, setIsPulling] = useState(false); 
  const [isInitialLoading, setIsInitialLoading] = useState(true);
  const [syncError, setSyncError] = useState(false);
  
  const [isCloudInitialized, setIsCloudInitialized] = useState(() => {
    return localStorage.getItem('smartshop_cloud_ready') === 'true';
  });
  
  const lastPulledHash = useRef<string>(''); 

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('smartshop_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('smartshop_transactions');
    return saved ? JSON.parse(saved) : [];
  });

  const [storeInfo, setStoreInfo] = useState<StoreInfo>(() => {
    const saved = localStorage.getItem('smartshop_store_info');
    const info = saved ? JSON.parse(saved) : DEFAULT_STORE_INFO;
    if (!info.categories) info.categories = DEFAULT_STORE_INFO.categories;
    return info;
  });

  const [deletedProductIds, setDeletedProductIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('smartshop_deleted_product_ids');
    return saved ? JSON.parse(saved) : [];
  });

  const [logs, setLogs] = useState<LogEntry[]>(() => {
    const saved = localStorage.getItem('smartshop_logs');
    return saved ? JSON.parse(saved) : [];
  });

  // Persist local
  useEffect(() => { localStorage.setItem('smartshop_products', JSON.stringify(products)); }, [products]);
  useEffect(() => { localStorage.setItem('smartshop_transactions', JSON.stringify(transactions)); }, [transactions]);
  useEffect(() => { 
    localStorage.setItem('smartshop_store_info', JSON.stringify(storeInfo));
    localStorage.setItem('smartshop_cloud_ready', isCloudInitialized.toString());
  }, [storeInfo, isCloudInitialized]);
  useEffect(() => { localStorage.setItem('smartshop_deleted_product_ids', JSON.stringify(deletedProductIds)); }, [deletedProductIds]);
  useEffect(() => { localStorage.setItem('smartshop_logs', JSON.stringify(logs)); }, [logs]);

  const mergeData = useCallback((cloudData: { products: Product[], transactions: Transaction[], storeInfo?: Partial<StoreInfo> }) => {
    const dataHash = JSON.stringify({
      p: cloudData.products.length,
      t: cloudData.transactions.length,
      lt: cloudData.transactions[0]?.id || ''
    });

    if (dataHash === lastPulledHash.current) return;
    lastPulledHash.current = dataHash;

    // Đồng bộ Sản phẩm (Bao gồm cả xóa)
    setProducts(prev => {
      const merged = [...prev];
      cloudData.products.forEach(cp => {
        // Chuyển đổi kiểu dữ liệu từ Cloud để khớp với Local
        const sanitizedCp: Product = {
          id: String(cp.id),
          name: String(cp.name || ""),
          category: String(cp.category || ""),
          costPrice: Number(cp.costPrice) || 0,
          salePrice: Number(cp.salePrice) || 0,
          stock: Number(cp.stock) || 0,
          imageUrl: String(cp.imageUrl || ""),
          sku: String(cp.sku || ""),
          location: String(cp.location || "")
        };

        const idx = merged.findIndex(p => p.id === sanitizedCp.id);
        if (idx !== -1) {
          // So sánh từng trường quan trọng thay vì stringify toàn bộ để tránh lỗi do thứ tự thuộc tính
          const p = merged[idx];
          const hasChanged = 
            p.name !== sanitizedCp.name ||
            p.category !== sanitizedCp.category ||
            p.costPrice !== sanitizedCp.costPrice ||
            p.salePrice !== sanitizedCp.salePrice ||
            p.stock !== sanitizedCp.stock ||
            p.sku !== sanitizedCp.sku ||
            p.location !== sanitizedCp.location ||
            p.imageUrl !== sanitizedCp.imageUrl;

          if (hasChanged) merged[idx] = sanitizedCp;
        } else {
          merged.push(sanitizedCp);
        }
      });
      const cloudIds = new Set(cloudData.products.map(p => String(p.id)));
      return merged.filter(p => cloudIds.has(p.id));
    });

    // ĐỒNG BỘ GIAO DỊCH / LỊCH SỬ (QUAN TRỌNG: Cập nhật cơ chế xóa)
    setTransactions(prev => {
      const cloudIds = new Set(cloudData.transactions.map(t => String(t.id)));
      
      // 1. Lọc bỏ những giao dịch không còn tồn tại trên Cloud
      const filteredLocal = prev.filter(t => cloudIds.has(String(t.id)));
      
      // 2. Thêm hoặc cập nhật giao dịch từ Cloud vào Local
      const merged = [...filteredLocal];
      cloudData.transactions.forEach(ct => {
        const sanitizedCt: Transaction = {
          id: String(ct.id),
          timestamp: Number(ct.timestamp),
          total: Number(ct.total) || 0,
          discountPercent: Number(ct.discountPercent) || 0,
          finalAmount: Number(ct.finalAmount) || 0,
          type: (ct.type as any) || 'sale',
          items: typeof ct.items === 'string' ? JSON.parse(ct.items) : (ct.items || []),
          totalCost: Number(ct.totalCost) || 0
        };

        const idx = merged.findIndex(t => t.id === sanitizedCt.id);
        if (idx !== -1) {
          // Chỉ cập nhật nếu có thay đổi thực sự
          if (merged[idx].finalAmount !== sanitizedCt.finalAmount || merged[idx].timestamp !== sanitizedCt.timestamp) {
            merged[idx] = sanitizedCt;
          }
        } else {
          merged.push(sanitizedCt);
        }
      });
      
      return merged.sort((a, b) => b.timestamp - a.timestamp);
    });

    if (cloudData.storeInfo) {
      setStoreInfo(prev => ({ ...prev, ...cloudData.storeInfo, lastSync: Date.now() }));
    }
  }, []);

  // HÀM ĐỒNG BỘ KHI ẤN NÚT (PUSH)
  const triggerPushSync = async (
    currentProducts: Product[], 
    currentTransactions: Transaction[], 
    currentStore: StoreInfo,
    currentDeletions: string[],
    currentLogs: LogEntry[]
  ) => {
    if (!currentStore.googleSheetsUrl || !isCloudInitialized) return;
    
    setIsSyncing(true);
    setSyncError(false);
    try {
      await syncToGoogleSheets(
        currentStore.googleSheetsUrl, 
        currentProducts, 
        currentTransactions, 
        currentStore, 
        currentDeletions,
        currentLogs
      );
      setStoreInfo(prev => ({ ...prev, lastSync: Date.now() }));
      setDeletedProductIds(prev => prev.filter(id => !currentDeletions.includes(id)));
      setLogs(prev => prev.filter(l => !currentLogs.some(cl => cl.id === l.id)));
    } catch (error) {
      setSyncError(true);
    } finally {
      setIsSyncing(false);
    }
  };

  const handlePullData = useCallback(async (isInitial = false, isSilent = false) => {
    if (!storeInfo.googleSheetsUrl) {
      if (isInitial) setIsInitialLoading(false);
      return;
    }

    if (!isSilent) setIsPulling(true);
    try {
      const cloudData = await fetchFromGoogleSheets(storeInfo.googleSheetsUrl);
      if (cloudData) {
        mergeData(cloudData);
        setIsCloudInitialized(true);
        if (!isInitial && !isSilent) alert("Dữ liệu đã được cập nhật!");
      }
    } catch (error) {
      if (!isInitial && !isSilent) alert("Lỗi kết nối Cloud.");
    } finally {
      if (!isSilent) setIsPulling(false);
      if (isInitial) setIsInitialLoading(false);
    }
  }, [storeInfo.googleSheetsUrl, mergeData]);

  // Lấy dữ liệu lần đầu
  useEffect(() => { handlePullData(true); }, []);

  // CƠ CHẾ PULL IM LẶNG (KHI SHEET CÓ THAY ĐỔI THÌ ĐẨY VỀ APP)
  useEffect(() => {
    if (isCloudInitialized && storeInfo.googleSheetsUrl) {
      const interval = setInterval(() => {
        if (!isSyncing && !isPulling && document.visibilityState === 'visible') {
          handlePullData(false, true); // Chạy ngầm hoàn toàn im lặng
        }
      }, 20000); // Mỗi 20 giây kiểm tra 1 lần
      return () => clearInterval(interval);
    }
  }, [isCloudInitialized, storeInfo.googleSheetsUrl, isSyncing, isPulling, handlePullData]);

  // WRAPPERS CHO CÁC NÚT BẤM (ĐỂ TRIGGER SYNC)
  const handleSale = (newTransaction: Transaction) => {
    const updatedProducts = products.map(p => {
      const cartItem = newTransaction.items.find(item => item.id === p.id);
      if (cartItem) return { ...p, stock: p.stock - cartItem.quantity };
      return p;
    });
    const updatedTransactions = [newTransaction, ...transactions];
    
    setProducts(updatedProducts);
    setTransactions(updatedTransactions);
    
    // Đẩy lên Cloud ngay khi ấn Thanh toán
    triggerPushSync(updatedProducts, updatedTransactions, storeInfo, deletedProductIds, logs);
  };

  const handleUpdateInventory = (action: React.SetStateAction<Product[]>) => {
    let nextProducts: Product[];
    if (typeof action === 'function') {
      nextProducts = (action as (prev: Product[]) => Product[])(products);
    } else {
      nextProducts = action;
    }

    // Tìm các thay đổi để ghi log
    const logEntries: LogEntry[] = [];
    const timestamp = Date.now();

    // 1. Kiểm tra sửa đổi & Thêm mới
    nextProducts.forEach(newP => {
      const oldP = products.find(p => p.id === newP.id);
      if (oldP) {
        let changes = [];
        if (oldP.stock !== newP.stock) changes.push(`Tồn: ${oldP.stock} -> ${newP.stock}`);
        if (oldP.salePrice !== newP.salePrice) changes.push(`Giá: ${oldP.salePrice.toLocaleString()} -> ${newP.salePrice.toLocaleString()}`);
        if (oldP.costPrice !== newP.costPrice) changes.push(`Vốn: ${oldP.costPrice.toLocaleString()} -> ${newP.costPrice.toLocaleString()}`);
        
        if (changes.length > 0) {
          logEntries.push({
            id: `log-${timestamp}-${Math.random().toString(36).substr(2, 9)}`,
            timestamp,
            productId: newP.id,
            productName: newP.name,
            action: 'Cập nhật',
            details: changes.join(', ')
          });
        }
      } else {
        // Thêm mới
        logEntries.push({
          id: `log-${timestamp}-${Math.random().toString(36).substr(2, 9)}`,
          timestamp,
          productId: newP.id,
          productName: newP.name,
          action: 'Thêm mới',
          details: `Tồn: ${newP.stock}, Giá: ${newP.salePrice.toLocaleString()}`
        });
      }
    });

    // 2. Kiểm tra xóa
    const removed = products.filter(p => !nextProducts.find(n => n.id === p.id));
    const newDeletions = removed.length > 0 
      ? [...deletedProductIds, ...removed.map(r => String(r.id))]
      : deletedProductIds;

    removed.forEach(oldP => {
      logEntries.push({
        id: `log-${timestamp}-${Math.random().toString(36).substr(2, 9)}`,
        timestamp,
        productId: oldP.id,
        productName: oldP.name,
        action: 'Xóa',
        details: 'Đã xóa sản phẩm khỏi kho'
      });
    });

    if (removed.length > 0) setDeletedProductIds(newDeletions);
    setProducts(nextProducts);
    
    const updatedLogs = [...logs, ...logEntries];
    setLogs(updatedLogs);

    // Đẩy lên Cloud ngay khi ấn Lưu/Xóa sản phẩm
    triggerPushSync(nextProducts, transactions, storeInfo, newDeletions, updatedLogs);
  };

  const handleUpdateSettings = (newInfo: StoreInfo) => {
    setStoreInfo(newInfo);
    // Đẩy lên Cloud ngay khi ấn Lưu cài đặt
    triggerPushSync(products, transactions, newInfo, deletedProductIds, logs);
  };

  if (isInitialLoading) {
    return (
      <div className="h-screen w-full flex flex-col items-center justify-center bg-slate-50">
        <div className="w-16 h-16 border-4 border-indigo-100 border-t-indigo-600 rounded-full animate-spin"></div>
        <h2 className="mt-6 text-xl font-bold text-slate-800">SmartShop Cloud</h2>
        <p className="text-slate-500 text-sm">Đang kết nối dữ liệu...</p>
      </div>
    );
  }

  const handleTabChange = (tabId: string) => {
    if (tabId === 'settings' && !isSettingsUnlocked && storeInfo.adminPassword) {
      setShowSettingsLock(true);
    } else {
      if (activeTab === 'settings' && tabId !== 'settings') {
        setIsSettingsUnlocked(false);
      }
      setActiveTab(tabId);
    }
  };

  const handleSettingsUnlock = () => {
    setIsSettingsUnlocked(true);
    setShowSettingsLock(false);
    setActiveTab('settings');
  };

  return (
    <div className="flex h-screen bg-slate-50">
      <aside className={`${isSidebarOpen ? 'w-64' : 'w-20'} transition-all duration-300 bg-white border-r border-slate-200 flex flex-col no-print hidden md:flex`}>
        <div className="p-6 flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white shrink-0 shadow-lg shadow-indigo-100">
            <ShoppingCart size={24} />
          </div>
          {isSidebarOpen && <h1 className="font-bold text-xl truncate">SmartShop</h1>}
        </div>

        <nav className="flex-1 px-4 py-4">
          <ul className="space-y-1.5">
            {navItems.map((item) => (
              <li key={item.id}>
                <button onClick={() => handleTabChange(item.id)} className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-all ${activeTab === item.id ? 'bg-indigo-600 text-white shadow-md shadow-indigo-100' : 'text-slate-500 hover:bg-slate-50'}`}>
                  <item.icon size={20} className="shrink-0" />
                  {isSidebarOpen && <span className="font-semibold text-sm">{item.label}</span>}
                </button>
              </li>
            ))}
          </ul>
        </nav>

        <div className="p-4 border-t border-slate-100 space-y-3">
          {/* Status Badge - Chỉ hiện hiệu ứng khi ĐẨY lên theo yêu cầu */}
          <div className={`p-3 rounded-xl border flex items-center gap-3 transition-colors ${
            syncError ? 'bg-red-50 border-red-100 text-red-600' : 
            isSyncing ? 'bg-amber-50 border-amber-100 text-amber-600' : 
            'bg-emerald-50 border-emerald-100 text-emerald-600'
          }`}>
            <div className="shrink-0">
              {isSyncing ? <CloudUpload size={18} className="animate-bounce" /> :
               syncError ? <Cloud size={18} /> : 
               <Wifi size={18} />}
            </div>
            {isSidebarOpen && (
              <div className="min-w-0">
                <p className="text-[10px] font-bold uppercase tracking-tight">
                  {isSyncing ? 'Đang lưu Cloud...' : syncError ? 'Lỗi Cloud' : 'Cloud Trực Tuyến'}
                </p>
                <p className="text-[8px] opacity-70 italic">Chỉ lưu khi thao tác</p>
              </div>
            )}
          </div>

          <button onClick={() => handlePullData()} disabled={isPulling || isSyncing} className="w-full flex items-center gap-3 px-3 py-3 rounded-xl bg-slate-50 text-slate-600 hover:bg-slate-100 transition-colors border border-slate-200 disabled:opacity-50">
            {isPulling ? <Loader2 size={20} className="animate-spin" /> : <DownloadCloud size={20} />}
            {isSidebarOpen && <span className="font-bold text-[10px] uppercase">Làm mới dữ liệu</span>}
          </button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 no-print">
          <div className="flex items-center gap-4">
            <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2 hover:bg-slate-50 rounded-lg text-slate-500 hidden md:block">{isSidebarOpen ? <X size={20} /> : <Menu size={20} />}</button>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input type="text" placeholder="Tìm tên, SKU, vị trí..." className="pl-10 pr-4 py-2 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-500 w-64 md:w-96 text-sm" value={globalSearch} onChange={(e) => setGlobalSearch(e.target.value)} />
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-bold text-slate-900 leading-none">{storeInfo.name}</p>
              <p className="text-[10px] text-slate-400 mt-1.5 uppercase font-medium">{storeInfo.lastSync ? `Cập nhật: ${new Date(storeInfo.lastSync).toLocaleTimeString()}` : 'Chưa đồng bộ'}</p>
            </div>
            <div className="w-10 h-10 rounded-full border-2 border-white shadow-sm overflow-hidden bg-slate-100">
               <img src={`https://picsum.photos/seed/${storeInfo.name}/100/100`} className="w-full h-full object-cover" alt="Shop" />
            </div>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto p-4 md:p-8">
          {activeTab === 'dashboard' && <Dashboard products={products} transactions={transactions} onPull={() => handlePullData(false)} isPulling={isPulling} />}
          {activeTab === 'pos' && <POS products={products} onSale={handleSale} storeInfo={storeInfo} search={globalSearch} showCostPrice={storeInfo.showCostPrice} />}
          {activeTab === 'inventory' && <Inventory products={products} setProducts={handleUpdateInventory} search={globalSearch} categories={storeInfo.categories} adminPassword={storeInfo.stockPassword} onPull={() => handlePullData(false)} isPulling={isPulling} showCostPrice={storeInfo.showCostPrice} />}
          {activeTab === 'history' && <HistoryView transactions={transactions} />}
          {activeTab === 'settings' && <Settings storeInfo={storeInfo} setStoreInfo={handleUpdateSettings} />}
        </main>
      </div>

      {showSettingsLock && (
        <PasswordModal 
          correctPassword={storeInfo.adminPassword}
          onClose={() => setShowSettingsLock(false)}
          onSuccess={handleSettingsUnlock}
          title="Mật khẩu Quản trị"
          description="Vui lòng nhập mật khẩu hệ thống để truy cập Cài đặt."
        />
      )}
    </div>
  );
};

const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'pos', label: 'Bán hàng (POS)', icon: ShoppingCart },
  { id: 'inventory', label: 'Kho hàng', icon: Package },
  { id: 'history', label: 'Lịch sử', icon: History },
  { id: 'settings', label: 'Cài đặt', icon: SettingsIcon },
];

export default App;
