
import { Product, StoreInfo } from './types';

export const INITIAL_CATEGORIES: string[] = [
  'Điện thoại',
  'Laptop',
  'Phụ kiện',
  'Máy tính bảng',
  'Âm thanh',
  'Khác'
];

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'iPhone 15 Pro Max 256GB',
    category: 'Điện thoại',
    costPrice: 28000000,
    salePrice: 32990000,
    stock: 15,
    imageUrl: 'https://picsum.photos/seed/iphone15/400/400',
    sku: 'IP15PM-256',
    location: 'Kệ A1'
  },
  {
    id: '2',
    name: 'MacBook Air M3 13-inch',
    category: 'Laptop',
    costPrice: 24500000,
    salePrice: 28490000,
    stock: 8,
    imageUrl: 'https://picsum.photos/seed/macbookm3/400/400',
    sku: 'MBA-M3-13',
    location: 'Kệ B2'
  }
];

export const DEFAULT_STORE_INFO: StoreInfo = {
  name: 'SmartShop Manager Pro',
  address: '123 Đường Công Nghệ, Quận 1, TP. Hồ Chí Minh',
  phone: '0901234567',
  email: 'contact@smartshop.vn',
  website: 'www.smartshop.vn',
  categories: INITIAL_CATEGORIES,
  stockPassword: '123',
  adminPassword: 'admin',
  autoSync: false
};
