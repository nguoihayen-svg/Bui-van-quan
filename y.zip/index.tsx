
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

// Đăng ký Service Worker đơn giản để hỗ trợ cài đặt PWA
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    // Sử dụng đường dẫn chuỗi trực tiếp để tránh lỗi URL constructor trong một số môi trường
    navigator.serviceWorker.register('./sw.js')
      .catch(err => console.log('SW registration failed: ', err));
  });
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
